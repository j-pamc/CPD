#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

// Constantes definidas manualmente
#define G 6.67408e-11  // Constante gravitacional
#define EPSILON2 (0.005 * 0.005)  // Distância ao quadrado para colisão
#define DELTAT 0.1  // Intervalo de tempo
#define M_PI 3.14159265358979323846  // Valor de π definido manualmente

// Estrutura para representar uma partícula
typedef struct {
    double x, y;  // Posição (x, y)
    double vx, vy;  // Velocidade (vx, vy)
    double m;  // Massa
    int active;  // Indica se a partícula está ativa (1) ou colidiu (0)
} particle_t;

// Função para inicializar o gerador de números aleatórios
unsigned int seed;
void init_r4uni(int input_seed) {
    seed = input_seed + 987654321;
}

// Função para gerar um número aleatório uniforme entre 0 e 1
double rnd_uniform01() {
    int seed_in = seed;
    seed ^= (seed << 13);
    seed ^= (seed >> 17);
    seed ^= (seed << 5);
    return 0.5 + 0.2328306e-09 * (seed_in + (int)seed);
}

// Função para gerar um número aleatório normal (distribuição Gaussiana)
double rnd_normal01() {
    double u1, u2, z, result;
    do {
        u1 = rnd_uniform01();
        u2 = rnd_uniform01();
        z = sqrt(-2 * log(u1)) * cos(2 * M_PI * u2);  // Usa M_PI definido manualmente
        result = 0.5 + 0.15 * z;
    } while (result < 0 || result >= 1);
    return result;
}

// Função para inicializar as partículas
void init_particles(long seed, double side, long ncside, long long n_part, particle_t *par) {
    double (*rnd01)() = rnd_uniform01;
    long long i;

    // Se a semente for negativa, usa distribuição normal
    if (seed < 0) {
        rnd01 = rnd_normal01;
        seed = -seed;
    }

    // Inicializa o gerador de números aleatórios
    init_r4uni(seed);

    // Inicializa as partículas com posições, velocidades e massas aleatórias
    for (i = 0; i < n_part; i++) {
        par[i].x = rnd01() * side;
        par[i].y = rnd01() * side;
        par[i].vx = (rnd01() - 0.5) * side / ncside / 5.0;
        par[i].vy = (rnd01() - 0.5) * side / ncside / 5.0;
        par[i].m = rnd01() * 0.01 * (ncside * ncside) / n_part / G * EPSILON2;
        par[i].active = 1;  // Todas as partículas começam ativas
    }
}

// Função para calcular a força gravitacional entre duas partículas
void compute_force(particle_t *p1, particle_t *p2, double *fx, double *fy, int *collision) {
    double dx = p2->x - p1->x;
    double dy = p2->y - p1->y;
    double dist_sq = dx * dx + dy * dy;

    if (dist_sq < EPSILON2) {
        // Colisão: partículas evaporam
        p1->active = 0;
        p2->active = 0;
        *fx = 0;
        *fy = 0;
        *collision = 1;  // Indica que houve uma colisão
        return;
    }

    double force = G * p1->m * p2->m / dist_sq;
    double dist = sqrt(dist_sq);
    *fx = force * dx / dist;
    *fy = force * dy / dist;
    *collision = 0;  // Não houve colisão
}

// Função principal
int main(int argc, char *argv[]) {
    // Verifica se o número de argumentos está correto
    if (argc != 6) {
        fprintf(stderr, "Uso: %s <semente> <lado> <ncside> <n_part> <n_steps>\n", argv[0]);
        return 1;
    }

    // Lê os parâmetros da linha de comando
    long seed = atol(argv[1]);
    double side = atof(argv[2]);
    long ncside = atol(argv[3]);
    long long n_part = atoll(argv[4]);
    long long n_steps = atoll(argv[5]);

    // Aloca memória para as partículas
    particle_t *particles = malloc(n_part * sizeof(particle_t));
    if (!particles) {
        fprintf(stderr, "Erro ao alocar memória para partículas\n");
        return 1;
    }

    // Inicializa as partículas
    init_particles(seed, side, ncside, n_part, particles);

    // Medição do tempo de execução
    double exec_time = -omp_get_wtime();

    // Simulação
    long long collisions = 0;  // Contador de colisões
    for (long long step = 0; step < n_steps; step++) {
        // Para cada partícula, calcula a força resultante
        for (long long i = 0; i < n_part; i++) {
            if (!particles[i].active) continue;  // Ignora partículas inativas

            double fx = 0, fy = 0;

            // Calcula a força de todas as outras partículas sobre a partícula i
            for (long long j = i + 1; j < n_part; j++) {
                if (!particles[j].active) continue;  // Ignora partículas inativas
                double fxj, fyj;
                int collision;
                compute_force(&particles[i], &particles[j], &fxj, &fyj, &collision);
                fx += fxj;
                fy += fyj;
                collisions += collision;  // Incrementa o contador de colisões
            }

            // Atualiza a velocidade da partícula i
            particles[i].vx += fx / particles[i].m * DELTAT;
            particles[i].vy += fy / particles[i].m * DELTAT;
        }

        // Atualiza a posição de todas as partículas ativas
        for (long long i = 0; i < n_part; i++) {
            if (!particles[i].active) continue;

            particles[i].x += particles[i].vx * DELTAT;
            particles[i].y += particles[i].vy * DELTAT;

            // Verifica se a partícula saiu do espaço e a reposiciona no lado oposto
            if (particles[i].x < 0) particles[i].x += side;
            if (particles[i].x >= side) particles[i].x -= side;
            if (particles[i].y < 0) particles[i].y += side;
            if (particles[i].y >= side) particles[i].y -= side;
        }
    }

    // Finaliza a medição do tempo de execução
    exec_time += omp_get_wtime();
    fprintf(stderr, "%.6fs\n", exec_time);

    // Imprime o resultado final (posição da partícula 0 e número de colisões)
    printf("%.3f %.3f\n", particles[0].x, particles[0].y);
    printf("%lld\n", collisions);

    // Libera a memória alocada
    free(particles);

    return 0;
}